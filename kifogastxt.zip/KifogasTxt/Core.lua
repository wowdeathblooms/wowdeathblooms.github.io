local KIFOGAS_TXT = "KifogasTxt";
KifogasTxt = LibStub("AceAddon-3.0"):NewAddon(KIFOGAS_TXT, "AceConsole-3.0", "AceEvent-3.0", "AceComm-3.0")

local WrapTextInColorCode, SplitTextIntoLines = WrapTextInColorCode, SplitTextIntoLines

local db
local defaultDb = {
	profile = {
		KeepAccents = true
	},
}

function KifogasTxt:OnInitialize()
	-- create about pane
	LibStub("tekKonfig-AboutPanel").new(nil, KIFOGAS_TXT)

	-- create default db
 	self.db = LibStub("AceDB-3.0"):New("KifogasTxtDB", defaultDb)
	self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")

	-- cache
	db = self.db.profile

	-- create options table
	local options = {
			name = KIFOGAS_TXT,
			handler = KifogasTxt,
			type = 'group',
			args = {
				enable = {
				name = "Enable",
				desc = "Enables / disables the addon",
				type = "toggle",
				set = function(info,val) if (val) then KifogasTxt:Enable() else KifogasTxt:Disable() end end,
				get = function(info) return KifogasTxt.enabledState end
				},
				
				KeepAccents = {
					name = "Accents",
					desc = "keep accents in text?",
					type = "toggle",
					set = "_GenericSetter",
					get = function() return db.KeepAccents end
				},

				say = {
					name = "Say",
					desc = "Say random",
					type = "execute",
					func = function() KifogasTxt:SayRandom() end,
				},
			},
		}

	-- mix in the profile settings
	options.args.profile = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db)

	-- register slash commands
	LibStub("AceConfig-3.0"):RegisterOptionsTable(KIFOGAS_TXT, options, {"kft", "kifogas", "kifogastxt"})
	
	if (db["Disabled"]) then
		KifogasTxt:Disable();
	end
end

function KifogasTxt:COMBAT_LOG_EVENT_UNFILTERED()

	if not KifogasTxt.enabledState then
		return
	end

	--timestamp, event, hideCaster, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, destName, destFlags, destRaidFlags, extraArg1, extraArg2, extraArg3, extraArg4, extraArg5, extraArg6, extraArg7, extraArg8, extraArg9, extraArg10 = CombatLogGetCurrentEventInfo()
	local _,event,_,_,_,_,_,destGUID = CombatLogGetCurrentEventInfo()

	if ((event == "UNIT_DIED") and (UnitGUID("player") == destGUID)) then
		KifogasTxt:SayRandom()
	end

end

function KifogasTxt:OnProfileChanged(event, database, newProfileKey)
	db = database.profile
end

function KifogasTxt:_GenericSetter(info, value)
	db[info[#info]] = value
	KifogasTxt:Print(info[#info] .. " was set to: [|cff00ff00" .. tostring(value) .."|r]")
end

function KifogasTxt:OnEnable()
	db["Disabled"] = false
	KifogasTxt:Print("KifogásTxt is [|cff00ff00enabled|r]");

	KifogasTxt:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	KifogasTxt:RegisterComm(KIFOGAS_TXT, nil)
end

function KifogasTxt:OnCommReceived(...)
	local prefix, encodedString, channel, commSource = ...
	KifogasTxt:Print(encodedString);
end

function KifogasTxt:OnDisable()
	db["Disabled"] = true
	KifogasTxt:Print("KifogasTxt is [|cff00ff00disabled|r]");

	KifogasTxt:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
end

function KifogasTxt:SayRandom(target)
	
	local color = "|cffffff00"
	local rnd = KifogasTxt.prefixes[math.random(KifogasTxt.prefixesLength)].." "..KifogasTxt.suffixes[math.random(KifogasTxt.suffixesLength)]
	
	if (not db.KeepAccents) then
		rnd = KifogasTxt:Unaccent(rnd)
	end

	local rndUnitName = KifogasTxt:GetColoredName(KifogasTxt:GetRandomGroupUnitId(numGroupMembers)) or "valaki"
	local commSource = KifogasTxt:GetColoredName("player")

	rnd = string.format(rnd, "|r"..rndUnitName..color)
	rnd = commSource.." - "..color..rnd.."|r"

	KifogasTxt:SendCommMessage(KIFOGAS_TXT, rnd, "PARTY", nil)

end

local accents = {["ö"] = "o",["ü"] = "u",["ó"] = "o",["ő"] = "o",["ú"] = "u",["é"] = "e",["á"] = "a",["ű"] = "u",["í"] = "i",["Ö"] = "O",["Ü"] = "U",["Ó"] = "O",["Ő"]= "O",["Ú"] = "U",["É"] = "E",["Á"] = "A",["Ű"] = "U",["Í"] = "I"}

function KifogasTxt:Unaccent(value)

	for from,to in pairs(accents) do 
		value = gsub(value, from, to)
	end
	
	return value

end

function KifogasTxt:GetRandomGroupUnitId()

	local numGroupMembers = GetNumGroupMembers()
	if (numGroupMembers < 1) then 
		return nil 
	end

	local group = IsInRaid() and "raid" or "party"
	local unitnum = math.random(numGroupMembers)
	local unitid = group..unitnum;

	local currUnitName = GetUnitName(unitid)

	if (not currUnitName) or (currUnitName == GetUnitName("player")) then
		unitid = group..(unitnum > 1 and (unitnum-1) or (unitnum+1))
	end

	return unitid
end

function KifogasTxt:GetColoredName(unitid)

	if not unitid then return nil end

	local name = GetUnitName(unitid)
	if name then
		local englishClass = select(2, UnitClass(unitid));
		return WrapTextInColorCode(name, select(4, GetClassColor(englishClass)))
	end

end
